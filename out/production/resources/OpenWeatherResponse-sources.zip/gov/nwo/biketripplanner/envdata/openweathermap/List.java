
package gov.nwo.biketripplanner.envdata.openweathermap;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dt",
    "temp",
    "pressure",
    "humidity",
    "weather",
    "speed",
    "deg",
    "clouds"
})
public class List {

    @JsonProperty("dt")
    public Integer dt;
    @JsonProperty("temp")
    public Temp temp;
    @JsonProperty("pressure")
    public Float pressure;
    @JsonProperty("humidity")
    public Integer humidity;
    @JsonProperty("weather")
    public java.util.List<Weather> weather = null;
    @JsonProperty("speed")
    public Float speed;
    @JsonProperty("deg")
    public Integer deg;
    @JsonProperty("clouds")
    public Integer clouds;

}
