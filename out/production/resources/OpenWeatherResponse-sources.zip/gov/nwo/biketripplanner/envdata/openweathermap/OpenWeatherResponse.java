
package gov.nwo.biketripplanner.envdata.openweathermap;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "city",
    "cod",
    "message",
    "cnt",
    "list"
})
public class OpenWeatherResponse {

    @JsonProperty("city")
    public City city;
    @JsonProperty("cod")
    public String cod;
    @JsonProperty("message")
    public Float message;
    @JsonProperty("cnt")
    public Integer cnt;
    @JsonProperty("list")
    public java.util.List<gov.nwo.biketripplanner.envdata.openweathermap.List> list = null;

}
